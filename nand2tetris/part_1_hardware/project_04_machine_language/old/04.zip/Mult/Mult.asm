// This file is part of www.nand2tetris.org
// and the book "The Elements of Computing Systems"
// by Nisan and Schocken, MIT Press.
// File name: projects/4/Mult.asm

// Multiplies R0 and R1 and stores the result in R2.
// (R0, R1, R2 refer to RAM[0], RAM[1], and RAM[2], respectively.)
// The algorithm is based on repetitive addition.

// sum holds intermediate results
    @sum
    M=0

// pow holds R1 input raised to successive powers of 2
    @R1
    D=M
    @pow
    M=D

// R0 + 1 is the loop exit criteria
    @R0
    D=M+1
    @stop
    M=D

// i will iterate over powers of 2
    @i
    M=1

// loop from lsb to msb
(LOOP)
    @stop
    D=M
    @i
    D=D-M // (R0+1)-i > 0 if we are not done
    @DONE
    D;JLE

    // check if this digit is non-zero
    @R0
    D=M
    @i
    D=D&M
    @ITER
    D;JEQ // jump to index iteration, skip sum

    // add b * 2^i to the intermediate sum
    @pow
    D=M
    @sum
    M=D+M

// iterate by adding values to themselves:
// this is the same as multiplying by 2,
// which is the same as a left shift of 1
@ITER
    @pow
    D=M
    M=D+M
    @i
    D=M
    M=D+M

    // restart loop
    @LOOP
    0;JMP

// done multiplying
(DONE)
    @sum
    D=M
    @R2
    M=D

// end safely
(END)
    @END
    0;JMP